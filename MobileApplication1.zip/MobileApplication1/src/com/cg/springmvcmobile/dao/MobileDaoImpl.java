package com.cg.springmvcmobile.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcmobile.dto.Mobile;
import com.cg.springmvcmobile.service.IMobileService;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileService{

	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void addMobile(Mobile mob) {
		// TODO Auto-generated method stub
		entitymanager.persist(mob);
		entitymanager.flush();
		
	}

	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		Query queryone=entitymanager.createQuery("FROM Mobile");
		return queryone.getResultList();
	}

	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile SearchMobile(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
