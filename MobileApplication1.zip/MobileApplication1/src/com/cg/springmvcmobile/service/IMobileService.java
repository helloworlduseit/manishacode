package com.cg.springmvcmobile.service;

import java.util.List;

import com.cg.springmvcmobile.dto.Mobile;


public interface IMobileService {
	public void addMobile(Mobile mob);
	public List<Mobile> showAllMobiles();
	public void deleteMobile(int mobId);
	public void updateMobile(Mobile mob);
	public Mobile SearchMobile(int id);
}
