package com.cg.service;

import java.util.List;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;

public interface IShowService
{
	List<ShowDetails> getAllShowDetails() throws BookingException;
	int UpdateShowDetails(String showId,float noOfSeats) throws BookingException;

}
