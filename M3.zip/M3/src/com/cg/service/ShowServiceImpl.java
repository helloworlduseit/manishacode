package com.cg.service;

import java.util.List;

import com.cg.dao.IShowDao;
import com.cg.dao.ShowDaoImpl;
import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;


public class ShowServiceImpl implements IShowService
{
	IShowDao sdao=new ShowDaoImpl();

	@Override
	public List<ShowDetails> getAllShowDetails() throws BookingException
	{
		
		return sdao.getAllShowDetails();
	}

	@Override
	public int UpdateShowDetails(String showId, float noOfSeats)
			throws BookingException 
	{
		
		return sdao.UpdateShowDetails(showId,noOfSeats);
	}

}
