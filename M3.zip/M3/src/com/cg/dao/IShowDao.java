package com.cg.dao;

import java.util.List;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;



public interface IShowDao 
{
	List<ShowDetails> getAllShowDetails() throws BookingException;
	int UpdateShowDetails(String showId,float noOfSeats) throws BookingException;

}
