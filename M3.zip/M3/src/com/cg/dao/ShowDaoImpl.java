package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.Util.DBUtil;
import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;


public class ShowDaoImpl implements IShowDao
{
	Connection con=null;

	@Override
	public List<ShowDetails> getAllShowDetails() throws BookingException
	{
		List<ShowDetails>sList=new ArrayList<>();

		try
		{
			con=DBUtil.getConnection();
			Statement st=con.createStatement();
			ResultSet rst=st.executeQuery("SELECT * FROM ShowDetails");
			rst.next();
			System.out.println(rst.getString("ShowId"));
			while(rst.next()){
				ShowDetails s=new ShowDetails();
				s.setShowId(rst.getString("ShowId"));
				s.setShowName(rst.getString("ShowName "));
				s.setLocation(rst.getString("Location "));
				s.setDate(rst.getDate("ShowDate "));
				s.setAvailTicket(rst.getInt("AvSeats "));
				s.setPriceTicket(rst.getFloat("PriceTicket"));
				System.out.println(s.toString());
				
				sList.add(s);

			}
		}
		catch(SQLException e )
		{
			throw new BookingException("Problem in fetching list"+e.getMessage());
		}
		
		return sList;
	}

	@Override
	public int UpdateShowDetails(String showId, float noOfSeats)
			throws BookingException 
	{
		con=DBUtil.getConnection();
		PreparedStatement pst;
		int data = 0;
		try 
		{
			pst = con.prepareStatement(" UPDATE ShowDetails SET AvSeats=AvSeats-? WHERE SHOWID=?");
			pst.setFloat(1, noOfSeats);
			pst.setString(2, showId);
			data=pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();	
			throw new BookingException("Problem while Updating showDetails table in Database");
		}
		
		
		return data;
	}

}
