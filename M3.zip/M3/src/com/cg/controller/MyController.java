package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;
import com.cg.service.IShowService;
import com.cg.service.ShowServiceImpl;



@WebServlet(urlPatterns={"/showdetail","/Book","/update"})
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String url=request.getServletPath();
		String targetUrl="";
		IShowService Sser=new ShowServiceImpl();
		switch(url)
		{
		case "/showdetail":
		{
			
			try 
			{
				HttpSession sess=request.getSession();
				List<ShowDetails> showList;
				showList = Sser.getAllShowDetails();
				request.setAttribute("showList", showList);
				targetUrl="showdetails.jsp";
			} 
			catch (BookingException e) 
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		}
		
		case "/Book":
		{
			HttpSession sess=request.getSession();

			sess.setAttribute("ShowName", (String)request.getParameter("showName"));
			sess.setAttribute("Price", (String)request.getParameter("priceTicket"));
			sess.setAttribute("Seatsavail", (String)request.getParameter("availSeats"));
			targetUrl="bookingform.jsp";
		}
		
		break;
		case "/update":
		{
			HttpSession sess=request.getSession();
			String showId=(String) sess.getAttribute("id");
			sess.setAttribute("ShowName", (String)request.getParameter("sname"));
			sess.setAttribute("CName", (String)request.getParameter("cname"));
			sess.setAttribute("Mobileno", (String)request.getParameter("number"));
			sess.setAttribute("noofseats", (String)request.getParameter("number"));
			float noOfSeats = Float.parseFloat(request.getParameter("number"));
			float pricePerTicket = Float.parseFloat(request.getParameter("number"));
			
			int data;
			try {
				data = Sser.UpdateShowDetails(showId,noOfSeats);
				if (data==1)
				{
				float totalPrice=noOfSeats*pricePerTicket;
				sess.setAttribute("totalPrice",totalPrice );
				targetUrl="Success.jsp";
				}
				else
				{
					sess.setAttribute("error", "Problem while execution of Update Query");
					targetUrl="Error.jsp";
				}
			} 
			catch (BookingException e) 
			{
				
				sess.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
			
			
			
		}
		
		
		
			
			
			
			
			
				
			
		}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
			
			
    }
			
           
			
		
	}
	



