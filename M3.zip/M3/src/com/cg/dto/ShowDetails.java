package com.cg.dto;

import java.sql.Date;

public class ShowDetails 
{
	private String showId;
	private String showName;
	private String Location;
	private Date date;
	private int availTicket;
	private float priceTicket;
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getAvailTicket() {
		return availTicket;
	}
	public void setAvailTicket(int availTicket) {
		this.availTicket = availTicket;
	}
	public float getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(float priceTicket) {
		this.priceTicket = priceTicket;
	}
	public ShowDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShowDetails(String showId, String showName, String location, Date date,
			int availTicket, float priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		Location = location;
		this.date = date;
		this.availTicket = availTicket;
		this.priceTicket = priceTicket;
	}
	@Override
	public String toString() {
		return "ShowDetails [showId=" + showId + ", showName=" + showName
				+ ", Location=" + Location + ", date=" + date
				+ ", availTicket=" + availTicket + ", priceTicket="
				+ priceTicket + "]";
	}
	
	

}
